******************************************************
******************************************************

   *  *  G O T H I C  L O V E  L E T T E R S  *  *

               freeware by Belladonna
                        1999

******************************************************
******************************************************

This font is freeware. Permissions for redistribution
are given provided that this ReadMe file is included
each time.

If you choose to offer this font from a website or as
part of a collection, please inform me of where and
how it is being offered.

This font was originally offered from Sanguinus Curae
at www.sanguinus.com. If you like this font, feel free
to drop by and find more original freeware fonts by
Belladonna.

Contact me at belladonna@sanguinus.com.