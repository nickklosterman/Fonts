This font is made by typologic [formerly Dazzling Designs] and may be used free of charge for non-commercial projects. You may not distribute, sell, resell, change or modify this font. Feel free to upload the fonts to a free font site provided this disclaimer is included in the download (celticonsreadme.txt). Commercial or corporate use of the free fonts prohibited. For commercial or corporate use or publishing on e.g. CD ROM please contact: 

email: info@typologic.com




