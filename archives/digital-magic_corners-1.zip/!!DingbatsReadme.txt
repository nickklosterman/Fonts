Hi

These fonts are free to be used as you choose.. 
Not strings attached at all, just enjoy them..

Personal or Commercial use is ok..

ddad@pacific.net.au

Helen... 1999.