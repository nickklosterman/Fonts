                              

This LCR font is freeware, and was created by me, LeChefRen�, for 
your enjoyment.
  
It is intended for your personal use only, and is not to be sold 
or altered in any way.  It may be posted to websites and offered for 
download provided this readme .txt is left intact.
Also, please notify me in advance.

All LCR fonts are created with freeware and/or roalty-free clipart.  
I cannot be held responsible for any damage incurred by my fonts after
download.

I hope you enjoy this LCR font, and if you have any questions, please
don't hesitate to contact me at LCR Fonts@aol.com and please visit me
on the web at http://www.members.aol.com/lcrfonts

(((((HUGS)))))
     Ren�

ALL LCR fonts �Copyright 2001 by LeChefRene  All rights reserved