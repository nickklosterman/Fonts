
Hallo! Danke f�rs Herunterladen meiner Schrift! Sie wurde von Andreas H�feld, http://www.fontgrube.de, optimiert.

"Anke Calligraph" ist tats�chlich mittlerweile komplett kostenlos und darf kommerziell eingesetzt werden. Toll, nicht wahr?

Viel Spa� mit meiner Schrift!
Anke
www.anke-art.de

_____________________________________________

Hi and thank you for downloading my font! It was optimized by Andreas H�feld, http://www.fontgrube.de.

"Anke Calligraph" is completely free for personal and even commercial use. Cool, huh?

Have fun!
Anke
www.anke-art.de