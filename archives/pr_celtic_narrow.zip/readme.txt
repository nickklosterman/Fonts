This font contains some of the same capital letters as "PR uncial altcaps", but they are kerned to fit with these small letters in a dropped position.  Words typed in all capitals in this font will give an unsatisfactory appearance. For such applications, please use "PR uncial altcaps", or PR uncial which offers one set of characters in two sizes

the following symbols are included in this font for sake of completeness;


single and double quotes:alt+0146 through 0148
Trademark		alt+0153
Copyright		alt+0169
1/4			alt+0188
1/2			alt+0189
3/4			alt+0190

The only special character in this font is an alternative "l" which can be seen by typing alt+0204.  