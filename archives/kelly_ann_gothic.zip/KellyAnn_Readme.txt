Hi!

You�ve found one of DeNada Industries� many typefaces.

I hope you like!

This is shareware. I�m asking for a measly five bucks and ONLY 
if you use it. Don�t use it, don�t send me anything! Sound simple? 
Great!

My many typefaces include:
AlfredDrake
Grauman
EBrantScript
Heather
JoePerry
Juliet (See also Romeo)
KellyAnnGothic
KellyBrown
KrtRussell
LaurenScript
MachineScript
MissBrooks
PerryGothic
Romeo (see also Juliet)
SumDumGoi
Viking
WillRobinson

I think that�s all I've released... I haven�t been keeping good track!

These are all over the place. I released them on AOL and they�ve circled 
the globe a couple of times. That�s not my fault. Neither is it my fault 
if it arrives in your hands without everything intact. I don�t do support.  

If you�re looking for me to send you some of the files listed above, don�t 
ask me. Search. They�re somewhere! I highly recommend TypeOasis. 
(http://moorstation.org/typoasis/typoasis1.htm) It�s very well 
organized and they have my full endorsement.

If you wanna write and ask me questions, my e-mail address is 
Michael559@aol.com, but don�t be surprised if I�m a little grumpy. 
I�m just that way. And don�t be surprised if it takes me a little 
while to get back to you� e-mail may be faster than light, but I�m 
not� If you wanna write me and tell me that you just LOVE my typeface 
(or whatever) don�t. Just send me the shareware fee, then I�ll know 
you treasure it. Heck, if those nuns from Luxembourg can do it, so can you. 
You don�t have to send me a photo of your convent, though. 
On the other hand, it did make me smile and that�s never a bad thing.

If you wanna include this in some collection, or on your website, that�s cool. 
Please let me know. If you can give me a copy of the CD that�d be even better. 
You MUST include this readme file though. It�s important. Otherwise you�re nothing 
but a dang pirate and pirates can go hang!

After all that, please send that five bucks to:
Mike Allard
2603 NW 13th St, PMB 256
Gainesville, FL  32609

Cash is fine, just wrap it in a piece of paper and let me be surprised when 
I open the envelope. I love surprises. Send me more!

DeNada Industries (Don�t Worry, it�s Nothing)
Founded by a grumpy fellow when some software installation actually required a company 
name in the registration line. DeNada Industries has grown to include one employee 
(aka me). A producer of typefaces in their early years, DeNada has slowly 
undeveloped over the years to include the odd Theatre Flyer design for outrageous 
amounts of money. Their advertising budget is so severely limited as to preclude 
your being aware of their existence except by sheer accident. DeNada Industries 
is one of the slowest growing non-corporate entities in all of North America 
encompassing a wide variety of activities including: Typeface creation, flyer design, 
theatrical scenic and lighting design (in conjunction with The Shumway Brothers 
Moving Company) and a wide variety of other activities that defy specific 
categorization despite the heroic efforts of our staff.


Thanks,
The Staff (Mike)
Michael559@aol.com
