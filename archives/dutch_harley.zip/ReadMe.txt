
When using Dutch & Harley alt. you can customize your words the way you want!
Just use the "colon, comma,and parenthesis/brackets" to alter the ends of letters.
Use the "<,>" keys to add swirl effects.
Please leave comments if you have any questions.





This font is free for personal use only. For commercial use please visit
http://theoriginal19.blogspot.com or email barrybujol6@yahoo.com