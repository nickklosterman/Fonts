THANK YOU for downloading one of Kat's Fun Fonts!

By downloading or installing these fonts, you are agreeing to the terms of this license.

These fonts are free for personal and classroom use ONLY.

MY FILES MAY NOT BE USED FOR COMMERCIAL PURPOSES OR SOLD IN ANY WAY
without written authorization from me or a paid license.
Please contact me regarding license fees if interested.

My files MAY NEVER BE PLACED ON AN ARCHIVE CD AND SOLD COMMERCIALLY.

My fonts MAY be placed on any website available for download, providing proper CREDIT is given, a link back to me and this README.txt file is left in tact and attached to all of the KR files you offer for download AND YOU CONTACT ME FIRST FOR PERMISSION.

YOU MAY NOT directly link to my site or use my images or use my bandwith to offer the files.

I am not and can not be held resposible for any damages incurred to any computer after installing and/or using this font.

All fonts have been made BY HAND, BY HAND PLUS royalty free images or BY HAND PLUS images from a paid licensed third party.  
   
You can see all of my fonts at www.katsfunfonts.com

If you like this font or have an idea for a font, let me know! 

Thanks!

Kat Rakos

www.katsfunfonts.com
katsfunfonts@hotmail.com
kat@katsfunfonts.com

This font was created by Kat Rakos.